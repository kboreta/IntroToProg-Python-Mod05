# --------------------------------------------------------------------------------------------------- #
# Title: Assignment05
# Change Log: Kelela Boreta, 2024-07-31, Created Script
# Desc: Create a program that demonstrates the use of dictionaries, files, and exception handling
# --------------------------------------------------------------------------------------------------- #

import json

# Constants
MENU = '''
---- Course Registration Program ----
 Select from the following menu: 
    1. Register a Student for a Course
    2. Show current data  
    3. Save data to a file
    4. Exit the program
-----------------------------------------
'''
FILE_NAME = "Enrollments.json"

# Variables
student_first_name = ""
student_last_name = ""
course_name = ""
json_data = ""
file = None
menu_choice = ""
student_data = {}
students = []


# Function to load data from the file
def load_data():
    try:
        with open(FILE_NAME, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        return []


# On startup, load data from the file into a list of dictionaries
file = open(FILE_NAME, "r")
for row in file.readlines():
    # Parse the data from each line
    student_data = row.split(',')
    student_data = [student_data[0], student_data[1], student_data[2].strip()]
    # Add the parsed data to the collection
    students.append(student_data)
file.close()


# Load existing data
students = load_data()

# Main program loop
while True:
    print(MENU)
    menu_choice = input("Enter your choice: ")

    if menu_choice == "1":
        try:
            student_first_name = input("Enter student's first name: ").strip()
            if not student_first_name:
                raise ValueError("First name cannot be empty")
            student_last_name = input("Enter student's last name: ").strip()
            if not student_last_name:
                raise ValueError("Last name cannot be empty")
            course_name = input("Enter course name: ").strip()
            if not course_name:
                raise ValueError("Course name cannot be empty")

            student_data = {
                "first_name": student_first_name,
                "last_name": student_last_name,
                "course_name": course_name
            }
            students.append(student_data)
            print(f"Student {student_first_name} {student_last_name} registered for {course_name}")

        except ValueError as e:
            print(f"Input error: {e}")

    elif menu_choice == "2":
        if students:
            print("Current Registrations:")
            for student in students:
                print(f"{student['first_name']} {student['last_name']} - {student['course_name']}")
        else:
            print("No registrations found.")

    elif menu_choice == "3":
        save_data(students)
        print(f"Data saved to {FILE_NAME}")

    elif menu_choice == "4":
        print("Exiting program...")
        break

    else:
        print("Invalid choice. Please select from the menu options.")
